import { Component, OnInit } from '@angular/core';
import { SampleService } from './project-component.service';
import { ProjectDetail } from './project';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { UserDetail } from '../user-component/user';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-project-component',
  templateUrl: './project-component.component.html',
  styleUrls: ['./project-component.component.css'],
   providers: [ SampleService ]
})
export class ProjectComponentComponent implements OnInit {
smpls:string[];
inputtext=null;
sample=null
data:Array<ProjectDetail>=[];
userdata:Array<UserDetail>=[];
newProject : ProjectDetail;
fetchedProject : ProjectDetail;
priorityValue: string;
newUser : UserDetail;
fetchedUser : UserDetail;
userId:number;
isActive: boolean;
//myDate:date;

closeResult: string;
sampleDate:string;

  constructor(private sm: SampleService, private modalService: NgbModal) {
    this.newProject = new ProjectDetail();
	this.newUser = new UserDetail();
	this.fetchedUser = new UserDetail();
	this.fetchedProject=new ProjectDetail();
	this.isActive=false;
	this.getProject();
	/*this.myDate=new Date();
	this.newProject.start_date=this.datePipe.transform(this.myDate, 'yyyy-MM-dd');
	this.newProject.end_date=new Date();
    console.log(this.newProject.start_date);*/
	}
    clickAction()
{
	this.sample=this.inputtext
}
getProject()
{
	this.sm.getProject().subscribe(response => {
    console.log(response);
    this.data =response;
    
  });
}
 getProjectByID(id: number)
{
this.sm.getProjectById(id).subscribe(response => {
    console.log(response);
    this.fetchedProject =response;
	console.log('fetched Project is');
	console.log(this.fetchedProject);
    
  });
  

}

editProjectByID(id: number)
{
this.getProjectByID(id);
this.newProject.project_id=this.fetchedProject.project_id;
this.newProject.project=this.fetchedProject.project;
this.newProject.priority=this.fetchedProject.priority;
this.newProject.start_date=this.fetchedProject.start_date;
this.newProject.end_date=this.fetchedProject.end_date;
console.log('after edit');
console.log(this.fetchedUser);
console.log(this.newProject);
}
getUser()
{
	this.sm.getUser().subscribe(response => {
    console.log(response);
    this.userdata =response;
    
  });
}
getUserByID(id: number)
{
this.sm.getUserById(id).subscribe(response => {
    console.log(response);
    this.fetchedUser =response;
	console.log('fetched user is');
	console.log(this.fetchedUser);
    
  });
}


  ngOnInit() {
	  this.getUser();
  }
  addMore()
  {
    this.newProject.first_name=this.fetchedProject.first_name;
    this.sm.addProject(this.newProject).subscribe(response => {
      console.log(response);
      console.log(this.data);
      this.data.push(response);
      console.log(this.data);
    });
	  
}
open(content) {
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return  `with: ${reason}`;
    }
  }
  Search(){
  console.log('inSearch ()');
  }
 
}