import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ProjectDetail } from './project';
import { UserDetail } from '../user-component/user';


@Injectable()
export class SampleService{
	apiAddress:string;
	apiUserAddress:string;
	data:Array<ProjectDetail> = [];
	constructor(private http: HttpClient) { 
	
	this.apiAddress='http://localhost:8080/projectdetails/projects/';
	this.apiUserAddress='http://localhost:8080/userdetails/users/';
	}


getProject() {
 
   return this.http.get<Array<ProjectDetail>>(this.apiAddress);
   
}

addProject(projectDetail : ProjectDetail){
	return this.http.post<ProjectDetail>(this.apiAddress, projectDetail);
}

getProjectById(id: number) {
    return this.http.get<ProjectDetail>(`${this.apiAddress}${id}`);
  }
  
  getUser() {
 
   return this.http.get<Array<UserDetail>>(this.apiUserAddress);
   
}
getUserById(id: number) {
    return this.http.get<UserDetail>(`${this.apiUserAddress}${id}`);
  }
}