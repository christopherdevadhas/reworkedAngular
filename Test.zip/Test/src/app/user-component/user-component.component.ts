import { Component, OnInit } from '@angular/core';
import { SampleService } from './user-component.service';
import { UserDetail } from './user';
import { Options } from 'ng5-slider';


@Component({
  selector: 'app-user-component',
  templateUrl: './user-component.component.html',
  styleUrls: ['./user-component.component.css'],
  providers: [ SampleService ]
})
export class UserComponentComponent implements OnInit {
smpls:string[];
inputtext=null;
sample=null
data:Array<UserDetail>=[];
newUser : UserDetail;
fetchedUser : UserDetail;
value: number = 100;
  options: Options = {
    floor: 0,
    ceil: 250
  };

  constructor(private sm: SampleService) {
    this.newUser = new UserDetail();
	
    }
    clickAction()
{
	this.sample=this.inputtext
}
getUser()
{
	this.sm.getUser().subscribe(response => {
    console.log(response);
    this.data =response;
    
  });
}

  ngOnInit() {
	  this.getUser();
  }
  addMore()
  {
    
    this.sm.addUser(this.newUser).subscribe(response => {
      console.log(response);
      console.log(this.data);
      this.data.push(response);
      console.log(this.data);
    });
	  
}
deleteUser()
{
}
getUserByID(id: number)
{
this.sm.getUserById(id).subscribe(response => {
    console.log(response);
    this.fetchedUser =response;
	console.log('fetched user is');
	console.log(this.fetchedUser);
    
  });
}

editUserByID(id: number)
{
this.getUserByID(id);
this.newUser.employee_id=this.fetchedUser.employee_id;
this.newUser.project_id=this.fetchedUser.project_id;
this.newUser.task_id=this.fetchedUser.task_id;
this.newUser.first_name=this.fetchedUser.first_name;
this.newUser.last_name=this.fetchedUser.last_name;
console.log('after edit');
console.log(this.fetchedUser);
}

/*resetData()
{
this.newUser.employee_id='';
this.newUser.project_id='';
this.newUser.task_id='';
this.newUser.first_name='';
this.newUser.last_name='';
}
*/
}
